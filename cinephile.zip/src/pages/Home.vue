<template>
    <div>
        <Upcoming/>
        <Content type="movie"/>
        <Content type="tv"/>
    </div>
</template>

<script setup>
import Upcoming from '../components/Upcoming/Upcoming.vue';
import Content from '../components/Content/Content.vue';
</script>

<style lang="scss">

</style>