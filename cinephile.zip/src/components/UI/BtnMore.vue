<template>
    <router-link to="/" class="more">
        <font-awesome-icon :icon="['fas', 'bars-staggered']" class="more__icon" />
        Подробнее
    </router-link>
</template>

<script setup>

</script>

<style lang="scss">

</style>